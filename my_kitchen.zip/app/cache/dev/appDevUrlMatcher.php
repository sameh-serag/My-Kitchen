<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/api')) {
            if (0 === strpos($pathinfo, '/api/c')) {
                // api_1_get_countries
                if (0 === strpos($pathinfo, '/api/countries') && preg_match('#^/api/countries(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_1_get_countries;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_countries')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getCountriesAction',  '_format' => NULL,));
                }
                not_api_1_get_countries:

                // api_1_get_cities
                if (0 === strpos($pathinfo, '/api/cities') && preg_match('#^/api/cities/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_1_get_cities;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_cities')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getCitiesAction',  '_format' => NULL,));
                }
                not_api_1_get_cities:

                // api_1_get_chef_plates
                if (0 === strpos($pathinfo, '/api/chefs') && preg_match('#^/api/chefs/(?P<chef_id>[^/]++)/plates(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_1_get_chef_plates;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_chef_plates')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getChefPlatesAction',  '_format' => NULL,));
                }
                not_api_1_get_chef_plates:

                if (0 === strpos($pathinfo, '/api/cities')) {
                    // api_1_get_city_plates
                    if (preg_match('#^/api/cities/(?P<city_id>[^/]++)/plates(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_api_1_get_city_plates;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_city_plates')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getCityPlatesAction',  '_format' => NULL,));
                    }
                    not_api_1_get_city_plates:

                    // api_1_get_city_categories
                    if (preg_match('#^/api/cities/(?P<city_id>[^/]++)/categories(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_api_1_get_city_categories;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_city_categories')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getCityCategoriesAction',  '_format' => NULL,));
                    }
                    not_api_1_get_city_categories:

                    // api_1_get_city_chefs
                    if (preg_match('#^/api/cities/(?P<city_id>[^/]++)/chefs(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_api_1_get_city_chefs;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_city_chefs')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getCityChefsAction',  '_format' => NULL,));
                    }
                    not_api_1_get_city_chefs:

                }

            }

            // api_1_get_plate
            if (0 === strpos($pathinfo, '/api/plates') && preg_match('#^/api/plates/(?P<plate_id>[^/\\.]++)(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_api_1_get_plate;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_plate')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getPlateAction',  '_format' => NULL,));
            }
            not_api_1_get_plate:

            if (0 === strpos($pathinfo, '/api/chefs')) {
                // api_1_get_chef
                if (preg_match('#^/api/chefs/(?P<chef_id>[^/\\.]++)(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_1_get_chef;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_chef')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getChefAction',  '_format' => NULL,));
                }
                not_api_1_get_chef:

                // api_1_get_chef_requests
                if (preg_match('#^/api/chefs/(?P<chef_id>[^/]++)/requests(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_1_get_chef_requests;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_chef_requests')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getChefRequestsAction',  '_format' => NULL,));
                }
                not_api_1_get_chef_requests:

            }

            // api_1_get_user_orders
            if (0 === strpos($pathinfo, '/api/users') && preg_match('#^/api/users/(?P<user_id>[^/]++)/orders(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_api_1_get_user_orders;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_get_user_orders')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::getUserOrdersAction',  '_format' => NULL,));
            }
            not_api_1_get_user_orders:

            if (0 === strpos($pathinfo, '/api/r')) {
                // api_1_post_rating
                if (0 === strpos($pathinfo, '/api/ratings') && preg_match('#^/api/ratings(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_1_post_rating;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_post_rating')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::postRatingAction',  '_format' => NULL,));
                }
                not_api_1_post_rating:

                // api_1_post_register
                if (0 === strpos($pathinfo, '/api/registers') && preg_match('#^/api/registers(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_1_post_register;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_post_register')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::postRegisterAction',  '_format' => NULL,));
                }
                not_api_1_post_register:

            }

            // api_1_post_plate
            if (0 === strpos($pathinfo, '/api/plates') && preg_match('#^/api/plates(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_api_1_post_plate;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_post_plate')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::postPlateAction',  '_format' => NULL,));
            }
            not_api_1_post_plate:

            // api_1_post_request
            if (0 === strpos($pathinfo, '/api/requests') && preg_match('#^/api/requests(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_api_1_post_request;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_post_request')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::postRequestAction',  '_format' => NULL,));
            }
            not_api_1_post_request:

            // api_1_post_approve_request
            if (0 === strpos($pathinfo, '/api/approves/requests') && preg_match('#^/api/approves/requests(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_api_1_post_approve_request;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_post_approve_request')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::postApproveRequestAction',  '_format' => NULL,));
            }
            not_api_1_post_approve_request:

            // api_1_post_login
            if (0 === strpos($pathinfo, '/api/logins') && preg_match('#^/api/logins(?:\\.(?P<_format>json|xml|html))?$#s', $pathinfo, $matches)) {
                if ($this->context->getMethod() != 'POST') {
                    $allow[] = 'POST';
                    goto not_api_1_post_login;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_1_post_login')), array (  '_controller' => 'KitchenBundle\\Controller\\ApiController::postLoginAction',  '_format' => NULL,));
            }
            not_api_1_post_login:

            // nelmio_api_doc_index
            if (0 === strpos($pathinfo, '/api/doc') && preg_match('#^/api/doc(?:/(?P<view>[^/]++))?$#s', $pathinfo, $matches)) {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_nelmio_api_doc_index;
                }

                return $this->mergeDefaults(array_replace($matches, array('_route' => 'nelmio_api_doc_index')), array (  '_controller' => 'Nelmio\\ApiDocBundle\\Controller\\ApiDocController::indexAction',  'view' => 'default',));
            }
            not_nelmio_api_doc_index:

        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        if (0 === strpos($pathinfo, '/admin')) {
            // admin_home
            if (rtrim($pathinfo, '/') === '/admin') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'admin_home');
                }

                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::dashboardAction',  '_route' => 'admin_home',);
            }

            // sonata_admin_redirect
            if (rtrim($pathinfo, '/') === '/admin') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'sonata_admin_redirect');
                }

                return array (  '_controller' => 'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController::redirectAction',  'route' => 'sonata_admin_dashboard',  'permanent' => 'true',  '_route' => 'sonata_admin_redirect',);
            }

            // sonata_admin_dashboard
            if ($pathinfo === '/admin/dashboard') {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::dashboardAction',  '_route' => 'sonata_admin_dashboard',);
            }

            if (0 === strpos($pathinfo, '/admin/core')) {
                // sonata_admin_retrieve_form_element
                if ($pathinfo === '/admin/core/get-form-field-element') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:retrieveFormFieldElementAction',  '_route' => 'sonata_admin_retrieve_form_element',);
                }

                // sonata_admin_append_form_element
                if ($pathinfo === '/admin/core/append-form-field-element') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:appendFormFieldElementAction',  '_route' => 'sonata_admin_append_form_element',);
                }

                // sonata_admin_short_object_information
                if (0 === strpos($pathinfo, '/admin/core/get-short-object-description') && preg_match('#^/admin/core/get\\-short\\-object\\-description(?:\\.(?P<_format>html|json))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'sonata_admin_short_object_information')), array (  '_controller' => 'sonata.admin.controller.admin:getShortObjectDescriptionAction',  '_format' => 'html',));
                }

                // sonata_admin_set_object_field_value
                if ($pathinfo === '/admin/core/set-object-field-value') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:setObjectFieldValueAction',  '_route' => 'sonata_admin_set_object_field_value',);
                }

            }

            // sonata_admin_search
            if ($pathinfo === '/admin/search') {
                return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CoreController::searchAction',  '_route' => 'sonata_admin_search',);
            }

            if (0 === strpos($pathinfo, '/admin/c')) {
                // sonata_admin_retrieve_autocomplete_items
                if ($pathinfo === '/admin/core/get-autocomplete-items') {
                    return array (  '_controller' => 'sonata.admin.controller.admin:retrieveAutocompleteItemsAction',  '_route' => 'sonata_admin_retrieve_autocomplete_items',);
                }

                if (0 === strpos($pathinfo, '/admin/category')) {
                    // category_admin_list
                    if ($pathinfo === '/admin/category/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_list',  '_route' => 'category_admin_list',);
                    }

                    // category_admin_create
                    if ($pathinfo === '/admin/category/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_create',  '_route' => 'category_admin_create',);
                    }

                    // category_admin_batch
                    if ($pathinfo === '/admin/category/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_batch',  '_route' => 'category_admin_batch',);
                    }

                    // category_admin_edit
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'category_admin_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_edit',));
                    }

                    // category_admin_delete
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'category_admin_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_delete',));
                    }

                    // category_admin_show
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'category_admin_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_show',));
                    }

                    // category_admin_export
                    if ($pathinfo === '/admin/category/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'category_admin',  '_sonata_name' => 'category_admin_export',  '_route' => 'category_admin_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/country')) {
                    // country_admin_list
                    if ($pathinfo === '/admin/country/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_list',  '_route' => 'country_admin_list',);
                    }

                    // country_admin_create
                    if ($pathinfo === '/admin/country/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_create',  '_route' => 'country_admin_create',);
                    }

                    // country_admin_batch
                    if ($pathinfo === '/admin/country/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_batch',  '_route' => 'country_admin_batch',);
                    }

                    // country_admin_edit
                    if (preg_match('#^/admin/country/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'country_admin_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_edit',));
                    }

                    // country_admin_delete
                    if (preg_match('#^/admin/country/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'country_admin_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_delete',));
                    }

                    // country_admin_show
                    if (preg_match('#^/admin/country/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'country_admin_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_show',));
                    }

                    // country_admin_export
                    if ($pathinfo === '/admin/country/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'country_admin',  '_sonata_name' => 'country_admin_export',  '_route' => 'country_admin_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/city')) {
                    // city_admin_list
                    if ($pathinfo === '/admin/city/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_list',  '_route' => 'city_admin_list',);
                    }

                    // city_admin_create
                    if ($pathinfo === '/admin/city/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_create',  '_route' => 'city_admin_create',);
                    }

                    // city_admin_batch
                    if ($pathinfo === '/admin/city/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_batch',  '_route' => 'city_admin_batch',);
                    }

                    // city_admin_edit
                    if (preg_match('#^/admin/city/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'city_admin_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_edit',));
                    }

                    // city_admin_delete
                    if (preg_match('#^/admin/city/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'city_admin_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_delete',));
                    }

                    // city_admin_show
                    if (preg_match('#^/admin/city/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'city_admin_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_show',));
                    }

                    // city_admin_export
                    if ($pathinfo === '/admin/city/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'city_admin',  '_sonata_name' => 'city_admin_export',  '_route' => 'city_admin_export',);
                    }

                }

            }

            if (0 === strpos($pathinfo, '/admin/user')) {
                // user_admin_list
                if ($pathinfo === '/admin/user/list') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\UserController::listAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_list',  '_route' => 'user_admin_list',);
                }

                // user_admin_create
                if ($pathinfo === '/admin/user/create') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\UserController::createAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_create',  '_route' => 'user_admin_create',);
                }

                // user_admin_batch
                if ($pathinfo === '/admin/user/batch') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\UserController::batchAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_batch',  '_route' => 'user_admin_batch',);
                }

                // user_admin_edit
                if (preg_match('#^/admin/user/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_admin_edit')), array (  '_controller' => 'AdminBundle\\Controller\\UserController::editAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_edit',));
                }

                // user_admin_delete
                if (preg_match('#^/admin/user/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_admin_delete')), array (  '_controller' => 'AdminBundle\\Controller\\UserController::deleteAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_delete',));
                }

                // user_admin_show
                if (preg_match('#^/admin/user/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'user_admin_show')), array (  '_controller' => 'AdminBundle\\Controller\\UserController::showAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_show',));
                }

                // user_admin_export
                if ($pathinfo === '/admin/user/export') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\UserController::exportAction',  '_sonata_admin' => 'user_admin',  '_sonata_name' => 'user_admin_export',  '_route' => 'user_admin_export',);
                }

            }

            if (0 === strpos($pathinfo, '/admin/chef')) {
                // chef_admin_list
                if ($pathinfo === '/admin/chef/list') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\ChefController::listAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_list',  '_route' => 'chef_admin_list',);
                }

                // chef_admin_create
                if ($pathinfo === '/admin/chef/create') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\ChefController::createAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_create',  '_route' => 'chef_admin_create',);
                }

                // chef_admin_batch
                if ($pathinfo === '/admin/chef/batch') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\ChefController::batchAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_batch',  '_route' => 'chef_admin_batch',);
                }

                // chef_admin_edit
                if (preg_match('#^/admin/chef/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'chef_admin_edit')), array (  '_controller' => 'AdminBundle\\Controller\\ChefController::editAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_edit',));
                }

                // chef_admin_delete
                if (preg_match('#^/admin/chef/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'chef_admin_delete')), array (  '_controller' => 'AdminBundle\\Controller\\ChefController::deleteAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_delete',));
                }

                // chef_admin_show
                if (preg_match('#^/admin/chef/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'chef_admin_show')), array (  '_controller' => 'AdminBundle\\Controller\\ChefController::showAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_show',));
                }

                // chef_admin_export
                if ($pathinfo === '/admin/chef/export') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\ChefController::exportAction',  '_sonata_admin' => 'chef_admin',  '_sonata_name' => 'chef_admin_export',  '_route' => 'chef_admin_export',);
                }

            }

            if (0 === strpos($pathinfo, '/admin/plate')) {
                // plate_admin_list
                if ($pathinfo === '/admin/plate/list') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\PlateController::listAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_list',  '_route' => 'plate_admin_list',);
                }

                // plate_admin_create
                if ($pathinfo === '/admin/plate/create') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\PlateController::createAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_create',  '_route' => 'plate_admin_create',);
                }

                // plate_admin_batch
                if ($pathinfo === '/admin/plate/batch') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\PlateController::batchAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_batch',  '_route' => 'plate_admin_batch',);
                }

                // plate_admin_edit
                if (preg_match('#^/admin/plate/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'plate_admin_edit')), array (  '_controller' => 'AdminBundle\\Controller\\PlateController::editAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_edit',));
                }

                // plate_admin_delete
                if (preg_match('#^/admin/plate/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'plate_admin_delete')), array (  '_controller' => 'AdminBundle\\Controller\\PlateController::deleteAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_delete',));
                }

                // plate_admin_show
                if (preg_match('#^/admin/plate/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'plate_admin_show')), array (  '_controller' => 'AdminBundle\\Controller\\PlateController::showAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_show',));
                }

                // plate_admin_export
                if ($pathinfo === '/admin/plate/export') {
                    return array (  '_controller' => 'AdminBundle\\Controller\\PlateController::exportAction',  '_sonata_admin' => 'plate_admin',  '_sonata_name' => 'plate_admin_export',  '_route' => 'plate_admin_export',);
                }

            }

            if (0 === strpos($pathinfo, '/admin/r')) {
                if (0 === strpos($pathinfo, '/admin/rate')) {
                    // rate_admin_list
                    if ($pathinfo === '/admin/rate/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_list',  '_route' => 'rate_admin_list',);
                    }

                    // rate_admin_create
                    if ($pathinfo === '/admin/rate/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_create',  '_route' => 'rate_admin_create',);
                    }

                    // rate_admin_batch
                    if ($pathinfo === '/admin/rate/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_batch',  '_route' => 'rate_admin_batch',);
                    }

                    // rate_admin_edit
                    if (preg_match('#^/admin/rate/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'rate_admin_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_edit',));
                    }

                    // rate_admin_delete
                    if (preg_match('#^/admin/rate/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'rate_admin_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_delete',));
                    }

                    // rate_admin_show
                    if (preg_match('#^/admin/rate/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'rate_admin_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_show',));
                    }

                    // rate_admin_export
                    if ($pathinfo === '/admin/rate/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'rate_admin',  '_sonata_name' => 'rate_admin_export',  '_route' => 'rate_admin_export',);
                    }

                }

                if (0 === strpos($pathinfo, '/admin/request')) {
                    // request_admin_list
                    if ($pathinfo === '/admin/request/list') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_list',  '_route' => 'request_admin_list',);
                    }

                    // request_admin_create
                    if ($pathinfo === '/admin/request/create') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_create',  '_route' => 'request_admin_create',);
                    }

                    // request_admin_batch
                    if ($pathinfo === '/admin/request/batch') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_batch',  '_route' => 'request_admin_batch',);
                    }

                    // request_admin_edit
                    if (preg_match('#^/admin/request/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'request_admin_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_edit',));
                    }

                    // request_admin_delete
                    if (preg_match('#^/admin/request/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'request_admin_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_delete',));
                    }

                    // request_admin_show
                    if (preg_match('#^/admin/request/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'request_admin_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_show',));
                    }

                    // request_admin_export
                    if ($pathinfo === '/admin/request/export') {
                        return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'request_admin',  '_sonata_name' => 'request_admin_export',  '_route' => 'request_admin_export',);
                    }

                    if (0 === strpos($pathinfo, '/admin/request_details')) {
                        // request_details_admin_list
                        if ($pathinfo === '/admin/request_details/list') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::listAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_list',  '_route' => 'request_details_admin_list',);
                        }

                        // request_details_admin_create
                        if ($pathinfo === '/admin/request_details/create') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::createAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_create',  '_route' => 'request_details_admin_create',);
                        }

                        // request_details_admin_batch
                        if ($pathinfo === '/admin/request_details/batch') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::batchAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_batch',  '_route' => 'request_details_admin_batch',);
                        }

                        // request_details_admin_edit
                        if (preg_match('#^/admin/request_details/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'request_details_admin_edit')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::editAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_edit',));
                        }

                        // request_details_admin_delete
                        if (preg_match('#^/admin/request_details/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'request_details_admin_delete')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::deleteAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_delete',));
                        }

                        // request_details_admin_show
                        if (preg_match('#^/admin/request_details/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'request_details_admin_show')), array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::showAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_show',));
                        }

                        // request_details_admin_export
                        if ($pathinfo === '/admin/request_details/export') {
                            return array (  '_controller' => 'Sonata\\AdminBundle\\Controller\\CRUDController::exportAction',  '_sonata_admin' => 'request_details_admin',  '_sonata_name' => 'request_details_admin_export',  '_route' => 'request_details_admin_export',);
                        }

                    }

                }

            }

            // get_country_cities
            if ($pathinfo === '/admin/get_country_cities') {
                return array (  '_controller' => 'AdminBundle\\Controller\\AdminController::getCountryCitiesAction',  '_route' => 'get_country_cities',);
            }

        }

        if (0 === strpos($pathinfo, '/log')) {
            // login_check
            if ($pathinfo === '/login-check') {
                return array('_route' => 'login_check');
            }

            // logout
            if ($pathinfo === '/logout') {
                return array('_route' => 'logout');
            }

            // login
            if ($pathinfo === '/login') {
                return array (  '_controller' => 'AdminBundle\\Controller\\AdminController::loginAction',  '_route' => 'login',);
            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
