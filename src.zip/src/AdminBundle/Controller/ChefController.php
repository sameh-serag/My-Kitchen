<?php

namespace AdminBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

/**
 * Chef controller.
 */
class ChefController extends Controller {
    
}