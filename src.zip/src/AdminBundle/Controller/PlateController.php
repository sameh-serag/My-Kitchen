<?php

namespace AdminBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

/**
 * Plate controller.
 */
class PlateController extends Controller {
    
}