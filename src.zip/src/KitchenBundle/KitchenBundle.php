<?php

namespace KitchenBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KitchenBundle extends Bundle
{
}
